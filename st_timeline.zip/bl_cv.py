import streamlit as st
from streamlit_timeline import timeline
from pathlib import Path
# Set up the page configuration
st.set_page_config(page_title='CV Boris Labuda' ,layout="wide",page_icon='👧🏻')
st.markdown("""
    <style>
        .big-font {
            font-size: 50px !important;
            font-weight: bold;
            line-height: 0.5;
        }
        .tight-font {
            font-weight: bold;
            padding: 0px;
            font-size: 25px !important;
            margin: 0px;
            line-height: 0.5;
        }
        body {
            font-family: "Roboto";
            color: #333;
        }
        hd1 {
            font-family: "Roboto";
            color: #2E8B57;
        }
        hd2 {
            font-family: "Roboto";
        }
        hd3 {
            font-family: "Source Sans Pro";
        }
        .custom-title {
            font-size: 36px;
            color: navy;
            font-weight: bold;
        }
        html, body, [class*="css"]  {
             line-height: 1;
        }
    </style>
""", unsafe_allow_html=True)


CURRENT_DIR = Path(__file__).parent if "__file__" in locals() else Path.cwd()
RESUME_FILE = CURRENT_DIR / "resume.pdf"


#Header
st.markdown("<p class='big-font'>Ing. Boris Labuda</p>",unsafe_allow_html=True)
st.markdown("<p class='tight-font'>Process automation senior developer</p>",unsafe_allow_html=True)
# Contact Information
st.markdown("<p></p>",unsafe_allow_html=True)
st.write("📍 Martin, SK | 📧 blabuda@gmail.com | 🔗 [LinkedIn](https://linkedin.com/in/boris-labuda-498a5273)")
st.header("🧑‍💼 Profile")
st.write("""
Results-driven software engineer with 8+ years of experience designing and building scalable web applications. Passionate about clean code, performance, and cross-functional collaboration.
""")
# with open(RESUME_FILE, "rb") as pdf_file:
#     PDFbyte = pdf_file.read()
# st.download_button(label="📥 Download Resume", data=PDFbyte, file_name="Boris_Labuda_Resume.pdf", mime="application/pdf")

#timeline
with st.container():
    st.markdown("""""")
    st.subheader('Career Snapshot')

    # load data
    with open('example.json', "r") as f:
        data = f.read()

    # render timeline
    timeline(data, height=500,)

st.divider()
with st.container():
    col1,col2 = st.columns(2)
    with col1:
        # ----- EXPERIENCE -----
        st.markdown("<h2 class='hd1'> 💼 Work Experience</h2>",unsafe_allow_html=True)
        
        st.markdown("<h3>Process automation senior developer | Ecco Shoes",unsafe_allow_html=True)
        st.caption("Oct 2019 – Present")
        st.write("""
        - analysis, development and deploument of automated solutions in Blue Prism.
        - management of Blue Prism infrastructure.
        - development of custom Blue Prism scheduler and reporting app / license cost savings of 50%.
        """)        
        st.markdown("<h3>IT manager| Ecco Slovakia</h3>",unsafe_allow_html=True)
        st.caption("Jun 2010 – Sep 2019")
        st.write("""
        - Led a team of 4 IT specialists.
        - Responsibilities:
        -   IT infrastructure management.
        -   support for 200+ users.
        -   IT budget management.
        -   projects management.
        -   IT security management.
        -   vendor and asset management.
        -   local app development / VB.NET WinForms,ASP.NET,WPF.
        
        """)     
        st.markdown("<h3>SAP / IT specialist | Ecco Slovakia</h3>",unsafe_allow_html=True)
        st.caption("<p style='line-height: 0.2;'>Jun 2006 – Aug 2010</p>",unsafe_allow_html=True)
        st.write("""
        - SAP PP and WM user support.
        - SAP PP and WM master data maintenance.
        - General IT user support.
        """)
        st.markdown("<h3>SAP PP - master data specialist  | Ecco Slovakia</h3>",unsafe_allow_html=True)
        st.caption("<p style='line-height: 0.2;'>Oct 2004 – Jun 2006</p>",unsafe_allow_html=True)
        st.write("""
        - SAP PP master data maintenance.
        - SAP PP user support.
        """)
        st.markdown("<h3>Production planner  | Ecco Slovakia</h3>",unsafe_allow_html=True)
        st.caption("<p style='line-height: 0.2;'>Nov 2002 – Oct 2004</p>",unsafe_allow_html=True)
        st.write("""
        - planning shoe production schedule.        
        - reporting and prodution follow-up .
        """)
    with col2:
        st.markdown("<h2 class='hd1'> 📚 Education</h2>",unsafe_allow_html=True)
        # Škola 1 – Vysoká škola

        st.subheader("Žilinská univerzita v Žiline")
        st.write("**Inžiniersky titul, Prevádzka a ekonomika železničnej dopravy**")
        st.caption("09/1997 – 06/2002")

        st.subheader("Gymnázium V. P. Tótha, Martin")
        st.caption("09/1993 – 06/1997")
        st.divider()
        
        #certifikácia
        st.subheader("Certifikácie")
        st.write("""
        - **Blue Prism Developer Certification** (2020)
        """)
        st.divider()
        
        # Skills
        st.subheader("Zručnosti")
        st.write("""
        - Programovanie: VB.NET, C#, Python
        - Webové technológie: HTML, CSS, ASP.NET
        - Databázy: MSSQL, MySQL
        - Automatizácia: Blue Prism
        """)

